# General-Purpose Multi-Agent Developer AI Agent

A Python-based multi-agent software development assistant designed to run locally in Termux. It uses the configured Kilo AI Gateway model and includes an Orchestrator, seven specialist roles, quality validation, a workspace-scoped execution engine, automated checks, and ZIP packaging.

## Capabilities

- Natural-language task intake and task-mode detection (`analysis_only`, `plan_only`, `implementation`).
- Orchestrator planning and specialist selection: Analyst, Researcher, Architect, Frontend, Backend, QA, DevOps.
- Specialist responses with finish metadata and bounded repair for incomplete outputs.
- Quality validation and JSON run reports.
- Implementation mode (`--build`) that reads a bounded project snapshot, proposes complete file contents as JSON, pre-validates all changes, backs up replaced files, runs available checks, performs up to two repair rounds, and packages a ZIP.
- Bounded HTTP 429 retry handling for shared AI Gateway capacity limits.

## Quick start in Termux

Install Python if needed, extract this project, preserve your existing `.env`, then run:

```bash
python main.py --check
python -m compileall -q .
python -m unittest discover -s tests -q
```

Configure `.env` with `KILO_API_KEY`, `KILO_BASE_URL`, and `KILO_MODEL` as required. Never share `.env` or include it in a release ZIP.

## Run a task

Analysis only:

```bash
python main.py --task "Chỉ phân tích yêu cầu ..."
```

Plan only:

```bash
python main.py --task "Chỉ lập kế hoạch triển khai ..."
```

Build in a specific project workspace:

```bash
python main.py --build "Tạo ứng dụng ..." --workspace "$HOME/storage/shared/my_project"
```

The default deliverable ZIP is saved under `~/storage/downloads/`. Use `--output` to choose another path.

## Execution boundary

The file API confines read/write/delete operations to the selected workspace, rejects path traversal and external symlinks, protects secret files and internal directories, creates backups, and records an audit log. Only a fixed set of non-shell commands is allowed by the command runner.

This is **not an operating-system sandbox**. Test code runs with the Termux user's permissions. Only run builds against source code you trust. A successful automated check is not a substitute for manual product review, especially when the workspace has no automated tests.

See `README_EXECUTION_ENGINE.md` for operational details and safety limits.
