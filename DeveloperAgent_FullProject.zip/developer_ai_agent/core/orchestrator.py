import json
import re
from datetime import datetime
from pathlib import Path

from core.model_client import ModelClient
from agents.registry import SpecialistRegistry


class Orchestrator:
    MAX_CONTEXT_PER_AGENT = 1800
    MAX_CONTEXT_TOTAL = 6000
    MAX_CONTEXT_AGENTS = 3

    def __init__(self):
        self.model = ModelClient()
        self.registry = SpecialistRegistry()

    # ==========================================
    # TASK MODE
    # ==========================================

    def detect_task_mode(self, task):
        text = task.lower()

        analysis_phrases = [
            "chỉ phân tích",
            "chỉ phân tích yêu cầu",
            "analysis only",
            "analyze only",
        ]

        plan_phrases = [
            "chỉ lập kế hoạch",
            "chỉ thiết kế",
            "chưa viết code",
            "chưa cần code",
            "không viết code",
            "không tạo code",
            "không triển khai code",
            "chưa triển khai",
            "plan only",
            "no code",
        ]

        if any(phrase in text for phrase in analysis_phrases):
            return "analysis_only"

        if any(phrase in text for phrase in plan_phrases):
            return "plan_only"

        return "implementation"

    # ==========================================
    # PLANNING
    # ==========================================

    def run_task_with_metadata(self, task, mode="implementation",
                               repair_feedback=None):
        mode_rules = {
            "analysis_only": """
MODE: ANALYSIS ONLY.
Do not plan implementation tasks.
Do not request source code.
Focus on requirements, constraints, ambiguities and analysis.
""",
            "plan_only": """
MODE: PLAN ONLY.
The user does not authorize implementation code.
Do not include source code as a deliverable.
Plan, analyze, design and define verification procedures only.
""",
            "implementation": """
MODE: IMPLEMENTATION.
Plan the implementation requested by the user.
Include relevant development and verification specialists.
""",
        }

        messages = [
            {
                "role": "system",
                "content": f"""
You are the Orchestrator of a General-Purpose Multi-Agent
Software Development System.

Analyze the user's objective and produce a JSON execution plan.

{mode_rules[mode]}

Available specialist IDs:
analyst, researcher, architect, frontend, backend, qa, devops

Selection rules:
- The analyst must always be included.
- Include only specialists relevant to the task.
- Include architect for software architecture or design.
- Include frontend for frontend work.
- Include backend for backend work.
- Include QA when testing or quality verification is required.
- Include devops when deployment or packaging is required.
- Select specialists in dependency order.
- Do not include duplicate specialist IDs.

Return ONLY valid JSON with this structure:
{{
  "task_summary": "string",
  "deliverables": ["string"],
  "specialists": ["analyst", "architect"],
  "acceptance_criteria": ["string"],
  "risks": ["string"]
}}

Rules:
- Use Vietnamese.
- Do not invent user requirements.
- Do not claim work has already been executed.
- Keep the plan concise and specific.
- Follow the task mode strictly.
"""
            },
            {
                "role": "user",
                "content": task,
            },
        ]

        if repair_feedback:
            messages.append({
                "role": "user",
                "content": (
                    "Hãy tạo lại TOÀN BỘ JSON kế hoạch hợp lệ. "
                    "Không viết mã nguồn. Sửa các lỗi sau:\n"
                    + repair_feedback
                ),
            })

        method = getattr(self.model, "chat_with_metadata", None)
        if callable(method):
            response = method(messages, max_tokens=1800)
            if not isinstance(response, dict) or not isinstance(
                response.get("content"), str
            ):
                raise TypeError("Metadata kế hoạch không hợp lệ.")
            return response

        return {
            "content": self.model.chat(messages, max_tokens=1800),
            "finish_reason": None,
            "usage": None,
            "model": getattr(self.model, "model", None),
            "response_id": None,
            "metadata_available": False,
        }

    def run_task(self, task, mode="implementation"):
        # Giữ API cũ: run_task() trả về chuỗi JSON.
        return self.run_task_with_metadata(task, mode)["content"]

    def _parse_plan(self, raw, mode):
        text = raw.strip()

        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)

        start = text.find("{")
        end = text.rfind("}")

        if start < 0 or end < start:
            raise ValueError(
                "Orchestrator không trả về JSON hợp lệ."
            )

        plan = json.loads(text[start:end + 1])

        if not isinstance(plan, dict):
            raise ValueError("Execution plan phải là JSON object.")

        allowed = set(self.registry.agents.keys())

        selected = plan.get("specialists", [])

        if not isinstance(selected, list):
            raise ValueError("Danh sách specialists không hợp lệ.")

        selected = [
            item for item in selected
            if isinstance(item, str) and item in allowed
        ]

        selected = list(dict.fromkeys(selected))

        selected = ["analyst"] + [
            item for item in selected
            if item != "analyst"
        ]

        if mode == "analysis_only":
            selected = ["analyst"]

        plan["specialists"] = selected

        for field in (
            "deliverables",
            "acceptance_criteria",
            "risks",
        ):
            value = plan.get(field, [])

            if not isinstance(value, list):
                value = []

            plan[field] = [
                str(item).strip()
                for item in value
                if str(item).strip()
            ]

        plan["task_mode"] = mode

        if mode != "implementation":
            code_keywords = (
                "mã nguồn",
                "source code",
                "implementation code",
                "file html",
                "file css",
                "file javascript",
                "viết code",
                "lập trình hoàn chỉnh",
            )

            plan["deliverables"] = [
                item
                for item in plan["deliverables"]
                if not any(
                    keyword in item.lower()
                    for keyword in code_keywords
                )
            ]

        return plan

    # ==========================================
    # CONTEXT MANAGEMENT
    # ==========================================

    def _build_context(self, context_parts):
        selected = context_parts[-self.MAX_CONTEXT_AGENTS:]

        output = []

        for item in selected:
            remaining = (
                self.MAX_CONTEXT_TOTAL
                - sum(len(part) for part in output)
            )

            if remaining <= 0:
                break

            content = item[:self.MAX_CONTEXT_PER_AGENT]

            output.append(content[:remaining])

        return "\n\n".join(output)

    # ==========================================
    # QUALITY VALIDATION
    # ==========================================

    def _validate_result(self, result, mode, metadata=None):
        violations = []
        warnings = []

        if not isinstance(result, str) or not result.strip():
            return {
                "quality_status": "rejected",
                "violations": ["Phản hồi rỗng hoặc không phải văn bản."],
                "warnings": [],
            }

        text = result.strip()
        metadata = metadata if isinstance(metadata, dict) else {}
        finish_reason = metadata.get("finish_reason")
        finish_reason_text = (
            str(finish_reason).strip().lower()
            if finish_reason is not None else ""
        )
        if finish_reason_text in {
            "length", "max_tokens", "max_token",
            "max_output_tokens", "token_limit",
        }:
            violations.append(
                "Model kết thúc do giới hạn token (finish_reason="
                + finish_reason_text + ")."
            )

        if len(text) < 80:
            warnings.append(
                "Phản hồi quá ngắn, cần xem xét mức độ đầy đủ."
            )

        # Chỉ phát hiện lặp liên tiếp theo khối; không phạt thuật ngữ
        # chuyên ngành xuất hiện hợp lý ở nhiều phần khác nhau của báo cáo.
        normalized = re.sub(r"\\s+", " ", text.lower())
        words = normalized.split()

        if len(words) >= 30:
            repeated = False

            # Một cụm 3-12 từ phải bị lặp liền nhau ít nhất 5 lần
            # mới được xem là dấu hiệu nội dung bị lặp bất thường.
            for size in range(3, 13):
                for start in range(len(words) - size * 5 + 1):
                    phrase = words[start:start + size]
                    repetitions = 1
                    cursor = start + size

                    while (
                        cursor + size <= len(words)
                        and words[cursor:cursor + size] == phrase
                    ):
                        repetitions += 1
                        cursor += size

                    if repetitions >= 5:
                        repeated = True
                        break

                if repeated:
                    break

            if repeated:
                violations.append(
                    "Phát hiện một cụm nội dung bị lặp liên tiếp bất thường."
                )

        # Phát hiện dấu hiệu vi phạm chế độ không viết code.
        if mode in ("analysis_only", "plan_only"):
            code_patterns = [
                r"```",
                r"^\s*(?:def|class|import|from)\s+\w+",
                r"^\s*(?:const|let|var)\s+\w+\s*=",
                r"^\s*function\s+\w+\s*\(",
                r"^\s*<html(?:\s|>)",
                r"^\s*<!doctype\s+html",
            ]

            for pattern in code_patterns:
                if re.search(
                    pattern,
                    text,
                    flags=re.IGNORECASE | re.MULTILINE,
                ):
                    violations.append(
                        "Có dấu hiệu tạo mã nguồn trái với task mode."
                    )
                    break

        # Phát hiện code fence chưa được đóng.
        if text.count("```") % 2 != 0:
            warnings.append(
                "Có code fence chưa đóng, phản hồi có thể bị cắt."
            )

        # Không tự kết luận phản hồi bị cắt chỉ vì kết thúc bằng
        # dấu câu hoặc một câu chưa hoàn chỉnh.

        if violations:
            quality_status = "rejected"
        elif warnings:
            quality_status = "needs_review"
        else:
            quality_status = "accepted"

        return {
            "quality_status": quality_status,
            "violations": violations,
            "warnings": warnings,
        }

    def _metadata_needs_repair(self, metadata, quality=None):
        metadata = metadata if isinstance(metadata, dict) else {}
        reason = str(metadata.get("finish_reason") or "").strip().lower()
        if reason in {
            "length", "max_tokens", "max_token",
            "max_output_tokens", "token_limit",
        }:
            return True
        return bool(
            quality and quality.get("quality_status") == "rejected"
        )

    @staticmethod
    def _repair_feedback(metadata, quality=None):
        parts = []
        reason = metadata.get("finish_reason") if isinstance(metadata, dict) else None
        if reason:
            parts.append(f"finish_reason lần trước: {reason}.")
        if quality:
            parts.extend(quality.get("violations", []))
            parts.extend(quality.get("warnings", []))
        if not parts:
            parts.append("Phản hồi trước chưa đạt yêu cầu hoàn chỉnh.")
        return "- " + "\n- ".join(parts)

    # ==========================================
    # PIPELINE
    # ==========================================

    def run_pipeline(self, task):
        started = datetime.now()

        mode = self.detect_task_mode(task)

        print("\n===== TASK MODE =====")
        print(mode)

        print("\n===== ORCHESTRATOR: PLANNING =====")

        plan_response = self.run_task_with_metadata(task, mode)
        plan_metadata = {
            key: plan_response.get(key)
            for key in ("finish_reason", "usage", "model", "response_id")
        }
        raw_plan = plan_response["content"]
        try:
            plan = self._parse_plan(raw_plan, mode)
            plan_error = None
        except Exception as exc:
            plan = None
            plan_error = f"{type(exc).__name__}: {exc}"

        if self._metadata_needs_repair(plan_metadata) or plan_error:
            feedback = self._repair_feedback(plan_metadata)
            if plan_error:
                feedback += "\n- Lỗi phân tích JSON: " + plan_error
            repaired = self.run_task_with_metadata(
                task, mode, repair_feedback=feedback
            )
            plan_metadata = {
                key: repaired.get(key)
                for key in ("finish_reason", "usage", "model", "response_id")
            }
            plan = self._parse_plan(repaired["content"], mode)

        print("\n===== EXECUTION PLAN =====")
        print(json.dumps(
            plan,
            ensure_ascii=False,
            indent=2,
        ))

        results = []
        context_parts = []

        for index, agent_id in enumerate(
            plan["specialists"],
            start=1,
        ):
            agent = self.registry.get(agent_id)

            print(
                f"\n===== SPECIALIST {index}/"
                f"{len(plan['specialists'])}: {agent.name} ====="
            )

            context = self._build_context(context_parts)

            try:
                runner = getattr(agent, "run_with_metadata", None)
                if callable(runner):
                    response = runner(
                        task=task, context=context, mode=mode
                    )
                else:
                    response = {
                        "content": agent.run(
                            task=task, context=context, mode=mode
                        ),
                        "finish_reason": None,
                        "usage": None,
                        "model": None,
                        "response_id": None,
                    }

                result = response["content"]
                quality = self._validate_result(result, mode, response)
                repair_attempted = False

                if self._metadata_needs_repair(response, quality):
                    repair_attempted = True
                    feedback = self._repair_feedback(response, quality)
                    if not callable(runner):
                        raise RuntimeError(
                            "Agent không hỗ trợ repair_with_metadata."
                        )
                    # Retry with a larger output budget. The previous
                    # implementation retried with the same limit, making
                    # token-truncation repairs likely to fail repeatedly.
                    base_budget = getattr(agent, "max_tokens", 1200)
                    repair_budget = min(max(base_budget * 2, 2000), 3000)
                    response = runner(
                        task=task,
                        context=context,
                        mode=mode,
                        repair_feedback=feedback,
                        max_tokens=repair_budget,
                    )
                    result = response["content"]
                    quality = self._validate_result(result, mode, response)

                record = {
                    "agent_id": agent_id,
                    "agent_name": agent.name,
                    "status": "received",
                    "quality_status": quality["quality_status"],
                    "violations": quality["violations"],
                    "warnings": quality["warnings"],
                    "result": result,
                    "metadata": {
                        "finish_reason": response.get("finish_reason"),
                        "usage": response.get("usage"),
                        "model": response.get("model"),
                        "response_id": response.get("response_id"),
                    },
                    "repair_attempted": repair_attempted,
                }

                results.append(record)

                # Chỉ chuyển tiếp kết quả có thể sử dụng.
                if quality["quality_status"] != "rejected":
                    context_parts.append(
                        f"RESULT FROM {agent.name}:\n"
                        f"{result[:self.MAX_CONTEXT_PER_AGENT]}"
                    )

                print(result)
                print(
                    "\nQUALITY:",
                    quality["quality_status"],
                )

                for warning in quality["warnings"]:
                    print("WARNING:", warning)

                for violation in quality["violations"]:
                    print("VIOLATION:", violation)

            except Exception as exc:
                error = f"{type(exc).__name__}: {exc}"

                results.append({
                    "agent_id": agent_id,
                    "agent_name": agent.name,
                    "status": "failed",
                    "quality_status": "not_evaluated",
                    "violations": [],
                    "warnings": [],
                    "error": error,
                })

                print("SPECIALIST ERROR:", error)

        finished = datetime.now()

        received = sum(
            1 for item in results
            if item["status"] == "received"
        )

        accepted = sum(
            1 for item in results
            if item.get("quality_status") == "accepted"
        )

        needs_review = sum(
            1 for item in results
            if item.get("quality_status") == "needs_review"
        )

        rejected = sum(
            1 for item in results
            if item.get("quality_status") == "rejected"
        )

        failed = sum(
            1 for item in results
            if item["status"] == "failed"
        )

        report = {
            "task": task,
            "task_mode": mode,
            "plan": plan,
            "planning_metadata": plan_metadata,
            "results": results,
            "summary": {
                "specialists": len(results),
                "received": received,
                "accepted": accepted,
                "needs_review": needs_review,
                "rejected": rejected,
                "failed": failed,
            },
            "started_at": started.isoformat(),
            "finished_at": finished.isoformat(),
            "duration_seconds": (
                finished - started
            ).total_seconds(),
        }

        output_dir = (
            Path(__file__).resolve().parent.parent
            / "artifacts"
        )

        output_dir.mkdir(
            parents=True,
            exist_ok=True,
        )

        filename = (
            "run_"
            + started.strftime("%Y%m%d_%H%M%S_%f")
            + ".json"
        )

        report_path = output_dir / filename

        report_path.write_text(
            json.dumps(
                report,
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )

        print("\n===== PIPELINE SUMMARY =====")
        print("SPECIALISTS:", len(results))
        print("RECEIVED:", received)
        print("ACCEPTED:", accepted)
        print("NEEDS REVIEW:", needs_review)
        print("REJECTED:", rejected)
        print("FAILED:", failed)
        print("REPORT:", report_path)

        return report
