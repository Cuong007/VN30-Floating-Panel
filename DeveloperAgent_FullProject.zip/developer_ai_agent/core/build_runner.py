"""Model-assisted implementation loop backed by the safe ExecutionEngine."""
from __future__ import annotations

import json
import re
from datetime import datetime
from pathlib import Path

from core.execution_engine import ExecutionEngine, ExecutionError
from core.model_client import ModelClient


class BuildError(RuntimeError):
    pass


class BuildRunner:
    MAX_SOURCE_FILES = 35
    MAX_CONTEXT_CHARS = 55000
    MAX_FILE_CHANGES = 20
    MAX_REPAIR_ROUNDS = 2

    def __init__(self, workspace: str | Path, model_client=None):
        self.engine = ExecutionEngine(workspace)
        self.model = model_client or ModelClient()

    def _snapshot(self) -> str:
        chunks, used = [], 0
        for item in self.engine.list_files(limit=500):
            rel = item["path"]
            if item["size"] > 120000:
                continue
            suffix = Path(rel).suffix.lower()
            if suffix not in {".py", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx", ".html", ".css", ".json", ".md", ".txt", ".toml", ".yaml", ".yml", ".xml", ".sh"}:
                continue
            if len(chunks) >= self.MAX_SOURCE_FILES:
                break
            try:
                content = self.engine.read_file(rel, max_chars=10000)
            except (ExecutionError, OSError):
                continue
            block = f"\n--- FILE: {rel} ---\n{content}\n"
            if used + len(block) > self.MAX_CONTEXT_CHARS:
                break
            chunks.append(block)
            used += len(block)
        return "".join(chunks) or "(Workspace hiện chưa có tệp mã nguồn văn bản.)"

    @staticmethod
    def _decode_first_json_object(raw: str) -> dict:
        """Decode the first complete JSON object, tolerating trailing model chatter."""
        if not isinstance(raw, str) or not raw.strip():
            raise BuildError("Model không trả về nội dung JSON.")
        text = re.sub(r"^\s*```(?:json)?\s*", "", raw.strip(), flags=re.IGNORECASE)
        start = text.find("{")
        if start < 0:
            raise BuildError("Model không trả về JSON object.")
        try:
            value, _end = json.JSONDecoder().raw_decode(text[start:])
        except json.JSONDecodeError as exc:
            raise BuildError(f"JSON do model tạo không hợp lệ: {exc}") from exc
        if not isinstance(value, dict):
            raise BuildError("JSON do model tạo phải là object.")
        return value

    @staticmethod
    def _extract_json(raw: str) -> dict:
        data = BuildRunner._decode_first_json_object(raw)
        if not isinstance(data.get("files"), list):
            raise BuildError("JSON phải có trường files dạng danh sách.")
        return data

    def _ask_for_changes(self, task: str, plan: dict, specialist_results: list, snapshot: str, repair: str = "") -> dict:
        compact_results = []
        for item in specialist_results:
            if item.get("quality_status") == "accepted":
                compact_results.append({"agent": item.get("agent_name"), "result": str(item.get("result", ""))[:3500]})
        system = """Bạn là Implementation Engineer của một hệ thống Multi-Agent Developer AI.
Nhiệm vụ: thực hiện yêu cầu bằng cách tạo/cập nhật tệp trong workspace.
Chỉ trả về MỘT JSON hợp lệ, không markdown, theo schema:
{"summary":"...","files":[{"path":"relative/path","content":"toàn bộ nội dung tệp UTF-8"}]}
Quy tắc bắt buộc:
- Chỉ dùng đường dẫn tương đối bên trong workspace; không dùng .., đường dẫn tuyệt đối.
- Không tạo/sửa .env, secrets, credentials, token, private key.
- Không xóa tệp; chỉ trả về tệp cần tạo hoặc thay thế.
- Giữ nguyên tính năng hiện có; chỉ sửa những gì cần thiết.
- Tạo mã nguồn hoàn chỉnh, không dùng placeholder/TODO thay cho chức năng cốt lõi.
- Ưu tiên thư viện sẵn có, tránh phụ thuộc mới nếu không cần.
- Nếu workspace có cấu trúc sẵn, tuân theo cấu trúc đó.
- Không tuyên bố đã chạy test; hệ thống sẽ tự chạy kiểm tra sau khi ghi tệp.
- Giới hạn tối đa 20 tệp thay đổi; nội dung mỗi tệp tối đa 2 MB.
- Nếu yêu cầu chưa đủ dữ liệu để triển khai an toàn, trả files=[] và giải thích trong summary.
"""
        user = {
            "user_request": task,
            "execution_plan": plan,
            "specialist_findings": compact_results,
            "workspace_snapshot": snapshot,
            "repair_feedback": repair or None,
        }
        response = self.model.chat_with_metadata(
            [{"role": "system", "content": system}, {"role": "user", "content": json.dumps(user, ensure_ascii=False)}],
            max_tokens=6500,
            temperature=0.15,
        )
        if str(response.get("finish_reason") or "").lower() in {
            "length", "max_tokens", "max_token", "max_output_tokens", "token_limit"
        }:
            # A single large JSON response is fragile on models with a small
            # completion budget. Fall back to a compact manifest followed by
            # one complete file per request. Nothing is written until every
            # file has been generated and validated.
            return self._ask_for_changes_incremental(
                task, plan, compact_results, snapshot, repair
            )
        return self._extract_json(response["content"])

    def _ask_for_changes_incremental(
        self, task: str, plan: dict, compact_results: list,
        snapshot: str, repair: str = ""
    ) -> dict:
        common = {
            "user_request": task,
            "execution_plan": plan,
            "specialist_findings": compact_results,
            "workspace_snapshot": snapshot,
            "repair_feedback": repair or None,
        }
        manifest_system = """Bạn là Implementation Engineer. Chia yêu cầu thành danh sách tệp cần tạo/cập nhật.
Chỉ trả JSON ngắn: {"summary":"...","files":[{"path":"relative/path","purpose":"..."}]}.
Tối đa 8 tệp thiết yếu. Không viết nội dung mã nguồn ở bước này.
Chỉ dùng đường dẫn tương đối trong workspace, không tạo .env/secrets, không xóa tệp.
Ưu tiên thư viện chuẩn Python. Không thêm phụ thuộc nếu không cần.
"""
        manifest_response = self.model.chat_with_metadata(
            [{"role": "system", "content": manifest_system},
             {"role": "user", "content": json.dumps(common, ensure_ascii=False)}],
            max_tokens=1800, temperature=0.1,
        )
        if str(manifest_response.get("finish_reason") or "").lower() in {
            "length", "max_tokens", "max_token", "max_output_tokens", "token_limit"
        }:
            raise BuildError("Model tiếp tục bị cắt khi lập danh sách tệp. Chưa ghi tệp.")
        try:
            manifest = self._extract_json(manifest_response["content"])
        except Exception as exc:
            raise BuildError(f"Manifest tạo mã không hợp lệ: {exc}") from exc
        specs = manifest["files"]
        if not specs or len(specs) > 8:
            raise BuildError("Manifest phải có từ 1 đến 8 tệp cần thiết.")
        seen = set()
        for spec in specs:
            if not isinstance(spec, dict) or not isinstance(spec.get("path"), str):
                raise BuildError("Mỗi mục manifest phải có path dạng chuỗi.")
            rel = spec["path"].strip()
            if rel in seen:
                raise BuildError(f"Manifest có đường dẫn trùng: {rel}")
            seen.add(rel)
            try:
                self.engine.resolve(rel)
            except ExecutionError as exc:
                raise BuildError(str(exc)) from exc

        generated = []
        file_system = """Bạn là lập trình viên triển khai. Hãy viết HOÀN CHỈNH đúng MỘT tệp được yêu cầu.
Chỉ trả JSON hợp lệ theo schema: {"path":"đúng đường dẫn","content":"toàn bộ nội dung tệp"}.
Không markdown, không giải thích ngoài JSON, không placeholder/TODO.
Mã phải chạy được, xử lý lỗi hợp lý, tương thích các tệp liên quan.
Không tạo tệp khác, không sửa .env/secrets, không dùng đường dẫn tuyệt đối hay .. .
"""
        for spec in specs:
            rel = spec["path"].strip()
            request_data = {
                **common,
                "file_to_generate": {"path": rel, "purpose": str(spec.get("purpose", ""))},
                "already_generated_files": generated,
                "instruction": "Chỉ sinh đúng tệp này; nội dung phải đầy đủ và gọn, không lặp lại tệp khác.",
            }
            file_response = self.model.chat_with_metadata(
                [{"role": "system", "content": file_system},
                 {"role": "user", "content": json.dumps(request_data, ensure_ascii=False)}],
                max_tokens=3800, temperature=0.1,
            )
            reason = str(file_response.get("finish_reason") or "").lower()
            if reason in {"length", "max_tokens", "max_token", "max_output_tokens", "token_limit"}:
                # One bounded retry with a tighter implementation request.
                request_data["instruction"] = (
                    "Lượt trước bị cắt. Sinh lại toàn bộ tệp này ngắn gọn hơn, "
                    "chỉ giữ chức năng bắt buộc; không giải thích, không markdown."
                )
                file_response = self.model.chat_with_metadata(
                    [{"role": "system", "content": file_system},
                     {"role": "user", "content": json.dumps(request_data, ensure_ascii=False)}],
                    max_tokens=4800, temperature=0.05,
                )
                reason = str(file_response.get("finish_reason") or "").lower()
            if reason in {"length", "max_tokens", "max_token", "max_output_tokens", "token_limit"}:
                raise BuildError(
                    f"Model bị cắt khi tạo riêng tệp {rel}. Chưa ghi tệp nào."
                )
            try:
                item = self._decode_first_json_object(file_response.get("content", ""))
            except BuildError as exc:
                raise BuildError(f"JSON nội dung tệp {rel} không hợp lệ: {exc}") from exc
            if not isinstance(item, dict) or item.get("path") != rel or not isinstance(item.get("content"), str):
                raise BuildError(f"Model không trả đúng path/content cho tệp {rel}.")
            generated.append({"path": rel, "content": item["content"]})
        return {"summary": manifest.get("summary", "Tạo mã theo từng tệp để tránh giới hạn token."), "files": generated}

    def _apply_files(self, files: list) -> list[dict]:
        if len(files) > self.MAX_FILE_CHANGES:
            raise BuildError(f"Model đề xuất {len(files)} tệp, vượt giới hạn {self.MAX_FILE_CHANGES}.")
        changes = []
        seen = set()
        validated = []
        # Preflight toàn bộ batch trước khi ghi tệp đầu tiên.
        for item in files:
            if not isinstance(item, dict) or not isinstance(item.get("path"), str) or not isinstance(item.get("content"), str):
                raise BuildError("Mỗi phần tử files phải có path và content dạng chuỗi.")
            rel = item["path"].strip()
            if rel in seen:
                raise BuildError(f"Model đề xuất trùng đường dẫn: {rel}")
            seen.add(rel)
            try:
                self.engine.resolve(rel)
            except ExecutionError as exc:
                raise BuildError(str(exc)) from exc
            if Path(rel).name in self.engine.EXCLUDED_FILES:
                raise BuildError(f"Từ chối ghi tệp bí mật: {rel}")
            if len(item["content"].encode("utf-8")) > self.engine.MAX_FILE_BYTES:
                raise BuildError(f"Tệp vượt giới hạn 2 MB: {rel}")
            validated.append((rel, item["content"]))
        for rel, content in validated:
            changes.append(self.engine.write_file(rel, content))
        return changes

    def execute(self, task: str, pipeline_report: dict, output_zip: str | Path) -> dict:
        started = datetime.now().astimezone()
        plan = pipeline_report.get("plan", {})
        specialist_results = pipeline_report.get("results", [])
        accepted = [x for x in specialist_results if x.get("quality_status") == "accepted"]
        if not accepted:
            raise BuildError("Không có kết quả Specialist được chấp nhận; dừng trước khi sửa workspace.")

        snapshot = self._snapshot()
        response = self._ask_for_changes(task, plan, accepted, snapshot)
        if not response["files"]:
            raise BuildError("Model không đề xuất thay đổi tệp: " + str(response.get("summary", "Không rõ lý do")))

        all_changes = []
        all_changes.extend(self._apply_files(response["files"]))
        checks = self.engine.run_standard_checks()
        repair_rounds = 0

        while checks and not all(x.get("passed") for x in checks) and repair_rounds < self.MAX_REPAIR_ROUNDS:
            repair_rounds += 1
            feedback = json.dumps(checks, ensure_ascii=False)[:14000]
            snapshot = self._snapshot()
            repaired = self._ask_for_changes(task, plan, accepted, snapshot, repair=feedback)
            if not repaired["files"]:
                break
            all_changes.extend(self._apply_files(repaired["files"]))
            checks = self.engine.run_standard_checks()

        checks_available = bool(checks)
        checks_passed = bool(checks) and all(x.get("passed") for x in checks)
        checks_successful = all(x.get("passed") for x in checks) if checks else True
        package = None
        if checks_successful:
            package = self.engine.package_zip(output_zip)

        report = {
            "task": task,
            "workspace": str(self.engine.workspace),
            "summary": response.get("summary", ""),
            "changes": all_changes,
            "checks": checks,
            "repair_rounds": repair_rounds,
            "checks_available": checks_available,
            "checks_passed": checks_passed,
            "package": package,
            "started_at": started.isoformat(),
            "finished_at": datetime.now().astimezone().isoformat(),
            "status": ("completed" if checks_passed else ("packaged_unverified" if not checks_available and package else "needs_repair")),
        }
        report_dir = self.engine.workspace / ".agent_logs"
        report_path = report_dir / ("build_" + started.strftime("%Y%m%d_%H%M%S_%f") + ".json")
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        report["report_path"] = str(report_path)
        return report
