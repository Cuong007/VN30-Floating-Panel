"""Safe, workspace-scoped execution engine for the Developer AI Agent."""
from __future__ import annotations

import hashlib
import json
import os
import shlex
import shutil
import subprocess
import tempfile
import time
import zipfile
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable


class ExecutionError(RuntimeError):
    pass


class ExecutionEngine:
    EXCLUDED_DIRS = {".git", ".venv", "venv", "__pycache__", "node_modules", ".pytest_cache", "artifacts"}
    EXCLUDED_FILES = {".env", ".env.local", ".env.production"}
    MAX_FILE_BYTES = 2 * 1024 * 1024
    MAX_COMMAND_SECONDS = 180

    def __init__(self, workspace: str | Path, backup_dir: str | Path | None = None):
        self.workspace = Path(workspace).expanduser().resolve()
        if not self.workspace.exists() or not self.workspace.is_dir():
            raise ExecutionError(f"Workspace không tồn tại hoặc không phải thư mục: {self.workspace}")
        self.backup_dir = Path(backup_dir).expanduser().resolve() if backup_dir else self.workspace / ".agent_backups"
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        self.log_dir = self.workspace / ".agent_logs"
        self.log_dir.mkdir(parents=True, exist_ok=True)

    def resolve(self, relative_path: str | Path) -> Path:
        raw = str(relative_path).replace("\\", "/")
        candidate = (self.workspace / raw).resolve()
        try:
            candidate.relative_to(self.workspace)
        except ValueError as exc:
            raise ExecutionError(f"Từ chối đường dẫn nằm ngoài workspace: {relative_path}") from exc
        blocked = {".git", ".agent_logs", ".agent_backups", ".venv", "venv", "node_modules"}
        if any(part in blocked for part in candidate.relative_to(self.workspace).parts):
            raise ExecutionError(f"Từ chối thao tác vào thư mục hệ thống/nội bộ: {relative_path}")
        if candidate == self.workspace:
            raise ExecutionError("Không cho phép thao tác trực tiếp lên thư mục gốc workspace.")
        return candidate

    def _log(self, event: dict) -> None:
        event = {"timestamp": datetime.now(timezone.utc).isoformat(), **event}
        path = self.log_dir / "execution.jsonl"
        with path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(event, ensure_ascii=False) + "\n")

    def list_files(self, limit: int = 500) -> list[dict]:
        items = []
        for path in sorted(self.workspace.rglob("*")):
            if any(part in self.EXCLUDED_DIRS or part.startswith(".agent_") for part in path.relative_to(self.workspace).parts):
                continue
            if not path.is_file() or path.name in self.EXCLUDED_FILES or ".bak" in path.name:
                continue
            try:
                path.resolve().relative_to(self.workspace)
                size = path.stat().st_size
            except OSError:
                continue
            items.append({"path": path.relative_to(self.workspace).as_posix(), "size": size})
            if len(items) >= limit:
                break
        return items

    def read_file(self, relative_path: str, max_chars: int = 30000) -> str:
        path = self.resolve(relative_path)
        if not path.is_file():
            raise ExecutionError(f"Không tìm thấy tệp: {relative_path}")
        if path.stat().st_size > self.MAX_FILE_BYTES:
            raise ExecutionError(f"Tệp vượt giới hạn đọc {self.MAX_FILE_BYTES} bytes.")
        try:
            content = path.read_text(encoding="utf-8")
        except UnicodeDecodeError as exc:
            raise ExecutionError("Không đọc tệp nhị phân như văn bản.") from exc
        return content[:max_chars]

    def _backup(self, path: Path) -> str | None:
        if not path.exists() or not path.is_file():
            return None
        relative = path.relative_to(self.workspace)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        target = self.backup_dir / stamp / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
        return str(target)

    def write_file(self, relative_path: str, content: str) -> dict:
        if not isinstance(content, str):
            raise ExecutionError("Nội dung tệp phải là chuỗi.")
        if len(content.encode("utf-8")) > self.MAX_FILE_BYTES:
            raise ExecutionError("Tệp mới vượt giới hạn 2 MB.")
        path = self.resolve(relative_path)
        if path.name in self.EXCLUDED_FILES:
            raise ExecutionError("Từ chối ghi tệp chứa cấu hình bí mật.")
        path.parent.mkdir(parents=True, exist_ok=True)
        backup = self._backup(path)
        fd, temp_name = tempfile.mkstemp(prefix=".agent_tmp_", dir=str(path.parent))
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="") as stream:
                stream.write(content)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temp_name, path)
        finally:
            if os.path.exists(temp_name):
                os.unlink(temp_name)
        digest = hashlib.sha256(content.encode("utf-8")).hexdigest()
        self._log({"action": "write_file", "path": str(relative_path), "sha256": digest, "backup": backup})
        return {"path": str(relative_path), "bytes": len(content.encode("utf-8")), "sha256": digest, "backup": backup}

    def delete_file(self, relative_path: str) -> dict:
        path = self.resolve(relative_path)
        if not path.is_file():
            raise ExecutionError(f"Không tìm thấy tệp: {relative_path}")
        backup = self._backup(path)
        path.unlink()
        self._log({"action": "delete_file", "path": str(relative_path), "backup": backup})
        return {"path": str(relative_path), "deleted": True, "backup": backup}

    @staticmethod
    def _validate_command(argv: list[str]) -> None:
        if not argv or not all(isinstance(x, str) and x for x in argv):
            raise ExecutionError("Lệnh phải là danh sách đối số không rỗng.")
        if any(x in {";", "&&", "||", "|", ">", ">>", "<", "`"} for x in argv):
            raise ExecutionError("Từ chối toán tử shell; lệnh được chạy không qua shell.")
        allowed = False
        if argv[0] in {"python", "python3"}:
            allowed = (
                len(argv) >= 3 and argv[1] == "-m" and
                ((argv[2] == "compileall" and len(argv) <= 10) or
                 (argv[2] == "unittest" and len(argv) <= 8) or
                 (argv[2] == "pytest" and len(argv) <= 8))
            )
        elif argv[0] == "pytest":
            allowed = len(argv) <= 8
        elif argv[0] == "node":
            allowed = len(argv) == 3 and argv[1] == "--check"
        elif argv[0] == "git":
            allowed = argv[1:] == ["diff", "--check"]
        if not allowed:
            raise ExecutionError("Lệnh chưa nằm trong danh sách an toàn. Được phép: python -m compileall, python -m unittest, pytest, node --check, git diff --check.")

    def run_command(self, command: list[str] | str, timeout: int = 120) -> dict:
        argv = shlex.split(command) if isinstance(command, str) else list(command)
        self._validate_command(argv)
        timeout = max(1, min(int(timeout), self.MAX_COMMAND_SECONDS))
        env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "PYTHONIOENCODING": "utf-8", "PYTHONDONTWRITEBYTECODE": "1"}
        started = time.monotonic()
        try:
            proc = subprocess.run(argv, cwd=self.workspace, env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout, shell=False)
            result = {"command": argv, "returncode": proc.returncode, "stdout": proc.stdout[-20000:], "stderr": proc.stderr[-20000:], "duration_seconds": round(time.monotonic() - started, 3), "passed": proc.returncode == 0}
        except subprocess.TimeoutExpired as exc:
            result = {"command": argv, "returncode": None, "stdout": str(exc.stdout or "")[-20000:], "stderr": "Quá thời gian cho phép.", "duration_seconds": round(time.monotonic() - started, 3), "passed": False, "timed_out": True}
        self._log({"action": "run_command", **result})
        return result

    def run_standard_checks(self) -> list[dict]:
        results = []
        source_files = self.list_files(limit=1000)
        python_files = [x for x in source_files if x["path"].endswith(".py")]
        if python_files:
            ignore = r"(^|/)(\.venv|venv|node_modules|\.git|\.agent_backups|\.agent_logs)/"
            results.append(self.run_command(["python", "-m", "compileall", "-q", "-x", ignore, "."]))
            if (self.workspace / "tests").is_dir():
                results.append(self.run_command(["python", "-m", "unittest", "discover", "-s", "tests", "-q"], timeout=180))
        if shutil.which("node"):
            js_files = [x["path"] for x in source_files if x["path"].endswith((".js", ".mjs", ".cjs"))]
            for relative in js_files[:30]:
                results.append(self.run_command(["node", "--check", relative]))
        if (self.workspace / ".git").exists() and shutil.which("git"):
            results.append(self.run_command(["git", "diff", "--check"]))
        return results

    def package_zip(self, output_path: str | Path) -> dict:
        output = Path(output_path).expanduser().resolve()
        if output == self.workspace or self.workspace in output.parents:
            raise ExecutionError("Tệp ZIP phải được lưu bên ngoài workspace.")
        output.parent.mkdir(parents=True, exist_ok=True)
        count = 0
        with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for path in sorted(self.workspace.rglob("*")):
                if not path.is_file():
                    continue
                try:
                    path.resolve().relative_to(self.workspace)
                except ValueError:
                    continue
                relative = path.relative_to(self.workspace)
                parts = relative.parts
                if any(part in self.EXCLUDED_DIRS or part.startswith(".agent_") for part in parts):
                    continue
                if path.name in self.EXCLUDED_FILES or ".bak" in path.name or path.suffix in {".pyc", ".pyo"}:
                    continue
                if path == output:
                    continue
                archive.write(path, Path(self.workspace.name) / relative)
                count += 1
        with zipfile.ZipFile(output) as archive:
            bad = archive.testzip()
            if bad:
                output.unlink(missing_ok=True)
                raise ExecutionError(f"ZIP lỗi tại: {bad}")
        digest = hashlib.sha256(output.read_bytes()).hexdigest()
        self._log({"action": "package_zip", "path": str(output), "files": count, "sha256": digest})
        return {"path": str(output), "files": count, "bytes": output.stat().st_size, "sha256": digest}
