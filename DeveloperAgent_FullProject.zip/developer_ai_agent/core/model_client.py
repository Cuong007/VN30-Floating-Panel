import json
import urllib.request
import urllib.error
import time
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime

from config.settings import (
    KILO_BASE_URL,
    KILO_MODEL,
    KILO_API_KEY,
    REQUEST_TIMEOUT,
    MAX_TOKENS,
    TEMPERATURE,
)


class ModelError(Exception):
    pass


class ModelClient:
    MAX_RATE_LIMIT_RETRIES = 2

    def __init__(self):
        self.endpoint = KILO_BASE_URL
        self.model = KILO_MODEL
        self.api_key = KILO_API_KEY

    @staticmethod
    def _rate_limit_delay(headers, attempt):
        """Honor provider reset hints, with a bounded wait per retry."""
        delay = min(2 ** (attempt + 1), 8)
        if headers:
            retry_after = headers.get("Retry-After")
            if retry_after:
                try:
                    delay = max(delay, float(retry_after))
                except (TypeError, ValueError):
                    try:
                        target = parsedate_to_datetime(retry_after)
                        if target.tzinfo is None:
                            target = target.replace(tzinfo=timezone.utc)
                        delay = max(delay, (target - datetime.now(timezone.utc)).total_seconds())
                    except (TypeError, ValueError, OverflowError):
                        pass
            reset = headers.get("X-RateLimit-Reset")
            if reset:
                try:
                    value = float(reset)
                    if value > 10_000_000_000:
                        value /= 1000.0
                    delay = max(delay, value - time.time())
                except (TypeError, ValueError):
                    pass
        return max(1.0, min(delay, 65.0))

    def chat_with_metadata(
        self,
        messages,
        temperature=None,
        max_tokens=None,
    ):
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": (
                TEMPERATURE if temperature is None else temperature
            ),
            "max_tokens": (
                MAX_TOKENS if max_tokens is None else max_tokens
            ),
        }

        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        body = json.dumps(payload).encode("utf-8")

        request = urllib.request.Request(
            self.endpoint,
            data=body,
            headers=headers,
            method="POST",
        )

        rate_attempt = 0
        while True:
            try:
                with urllib.request.urlopen(
                    request,
                    timeout=REQUEST_TIMEOUT,
                ) as response:
                    raw = response.read().decode("utf-8")
                break

            except urllib.error.HTTPError as exc:
                detail = exc.read().decode(
                    "utf-8",
                    errors="replace",
                )
                if exc.code == 429 and rate_attempt < self.MAX_RATE_LIMIT_RETRIES:
                    rate_attempt += 1
                    delay = self._rate_limit_delay(exc.headers, rate_attempt)
                    time.sleep(delay)
                    continue
                raise ModelError(
                    f"HTTP {exc.code}: {detail[:1500]}"
                ) from exc

            except urllib.error.URLError as exc:
                raise ModelError(
                    f"Không kết nối được AI Gateway: {exc.reason}"
                ) from exc

            except TimeoutError as exc:
                raise ModelError(
                    "Yêu cầu tới AI bị timeout."
                ) from exc

        try:
            result = json.loads(raw)

            choice = result["choices"][0]
            message = choice["message"]
            content = message.get("content")
            finish_reason = choice.get("finish_reason")

            # Some gateway/provider combinations return content=null when
            # reasoning consumes the output budget. Preserve finish metadata
            # so Orchestrator can issue its bounded repair instead of treating
            # this recoverable truncation as a malformed API response.
            if content is None and str(finish_reason or "").lower() in {
                "length", "max_tokens", "max_token", "max_output_tokens"
            }:
                content = ""

            if isinstance(content, list):
                content = "\n".join(
                    str(item.get("text", item))
                    if isinstance(item, dict)
                    else str(item)
                    for item in content
                )

            if not isinstance(content, str):
                raise ValueError("Model trả về nội dung không phải chuỗi.")
            if not content.strip() and str(finish_reason or "").lower() not in {
                "length", "max_tokens", "max_token", "max_output_tokens"
            }:
                raise ValueError("Model trả về nội dung rỗng.")

            return {
                "content": content.strip(),
                "finish_reason": finish_reason,
                "usage": result.get("usage"),
                "model": result.get("model"),
                "response_id": result.get("id"),
            }

        except (
            json.JSONDecodeError,
            KeyError,
            IndexError,
            TypeError,
            ValueError,
        ) as exc:
            raise ModelError(
                f"Phản hồi AI không đúng định dạng: {raw[:1500]}"
            ) from exc

    def chat(
        self,
        messages,
        temperature=None,
        max_tokens=None,
    ):
        result = self.chat_with_metadata(
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
        )

        return result["content"]
