import json
import unittest
from email.message import Message
from unittest.mock import patch
from urllib.error import HTTPError

from core.model_client import ModelClient


class FakeResponse:
    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def read(self):
        return json.dumps({
            "id": "retry-test",
            "model": "fake-model",
            "choices": [{"message": {"content": "Đã kết nối lại."}, "finish_reason": "stop"}],
            "usage": {"total_tokens": 3},
        }).encode("utf-8")


class ModelClientRetryTests(unittest.TestCase):
    def test_429_is_retried_and_returns_metadata(self):
        headers = Message()
        headers["Retry-After"] = "1"
        limited = HTTPError("https://example.invalid", 429, "busy", headers, None)
        client = ModelClient()
        with patch("core.model_client.urllib.request.urlopen", side_effect=[limited, FakeResponse()]) as call, patch("core.model_client.time.sleep") as sleep:
            result = client.chat_with_metadata([{"role": "user", "content": "test"}])
        self.assertEqual(result["content"], "Đã kết nối lại.")
        self.assertEqual(result["response_id"], "retry-test")
        self.assertEqual(call.call_count, 2)
        sleep.assert_called_once()

    def test_rate_limit_wait_is_bounded(self):
        headers = {"Retry-After": "9999"}
        self.assertEqual(ModelClient._rate_limit_delay(headers, 1), 65.0)


    def test_null_content_with_length_finish_reason_preserves_metadata(self):
        class TruncatedResponse:
            def __enter__(self): return self
            def __exit__(self, *args): return False
            def read(self):
                return json.dumps({
                    "id": "truncated-null",
                    "model": "fake-model",
                    "choices": [{"message": {"content": None}, "finish_reason": "length"}],
                }).encode("utf-8")
        with patch("core.model_client.urllib.request.urlopen", return_value=TruncatedResponse()):
            result = ModelClient().chat_with_metadata([{"role": "user", "content": "test"}])
        self.assertEqual(result["content"], "")
        self.assertEqual(result["finish_reason"], "length")
        self.assertEqual(result["response_id"], "truncated-null")


if __name__ == "__main__":
    unittest.main()
