import unittest
from agents.specialists.base import SpecialistAgent


class SequenceModel:
    model = "test-model"

    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = []

    def chat_with_metadata(self, messages, max_tokens=None):
        self.calls.append((messages, max_tokens))
        return self.responses.pop(0)


class SpecialistEmptyRetryTests(unittest.TestCase):
    def test_retries_empty_response_then_returns_text(self):
        model = SequenceModel([
            {"content": "", "finish_reason": "stop"},
            {"content": "Kết quả phân tích hợp lệ.", "finish_reason": "stop"},
        ])
        agent = SpecialistAgent("Analyst Agent", "analyst", "Analyze", model_client=model)
        result = agent.run_with_metadata("Phân tích yêu cầu", mode="analysis_only")
        self.assertEqual(result["content"], "Kết quả phân tích hợp lệ.")
        self.assertEqual(len(model.calls), 2)
        self.assertIn("Phản hồi trước hoàn toàn rỗng", model.calls[1][0][1]["content"])
        self.assertGreater(model.calls[1][1], model.calls[0][1])

    def test_retries_twice_and_returns_last_empty_for_quality_gate(self):
        model = SequenceModel([
            {"content": "", "finish_reason": "stop"},
            {"content": "", "finish_reason": "stop"},
            {"content": "", "finish_reason": "stop"},
        ])
        agent = SpecialistAgent("Analyst Agent", "analyst", "Analyze", model_client=model)
        result = agent.run_with_metadata("Phân tích yêu cầu", mode="analysis_only")
        self.assertEqual(result["content"], "")
        self.assertEqual(len(model.calls), 3)

    def test_does_not_retry_nonempty_response(self):
        model = SequenceModel([
            {"content": "Báo cáo đủ nội dung.", "finish_reason": "stop"},
        ])
        agent = SpecialistAgent("Analyst Agent", "analyst", "Analyze", model_client=model)
        result = agent.run_with_metadata("Phân tích yêu cầu", mode="analysis_only")
        self.assertEqual(result["content"], "Báo cáo đủ nội dung.")
        self.assertEqual(len(model.calls), 1)


if __name__ == "__main__":
    unittest.main()
