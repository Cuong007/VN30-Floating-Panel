
import json, sys, tempfile, unittest
from pathlib import Path
from unittest.mock import patch, MagicMock
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from core.model_client import ModelClient, ModelError
from agents.specialists.base import SpecialistAgent
from core.orchestrator import Orchestrator

class FakeResponse:
    def __init__(self, payload, status=200):
        self.payload = payload
        self.status = status
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def read(self): return json.dumps(self.payload).encode()

class FakeModel:
    model = "mock-model"
    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = []
    def chat_with_metadata(self, messages, temperature=None, max_tokens=None):
        self.calls.append((messages, temperature, max_tokens))
        item = self.responses.pop(0)
        if isinstance(item, Exception): raise item
        return item
    def chat(self, messages, temperature=None, max_tokens=None):
        r = self.chat_with_metadata(messages, temperature, max_tokens)
        return r["content"]

class FakeAgent:
    def __init__(self, name, responses):
        self.name=name; self.responses=list(responses); self.calls=[]; self.max_tokens=1800
    def run_with_metadata(self, task, context="", mode="implementation", repair_feedback=None, max_tokens=None):
        self.calls.append((task, context, mode, repair_feedback, max_tokens))
        item=self.responses.pop(0)
        if isinstance(item, Exception): raise item
        return item
    def run(self, task, context="", mode="implementation"):
        return self.run_with_metadata(task, context, mode)["content"]

def good(text="Đây là kết quả phân tích đầy đủ, có cấu trúc và đáp ứng nhiệm vụ được giao."):
    return {"content": text + (" Nội dung bổ sung để vượt ngưỡng đánh giá độ dài và mô phỏng một câu trả lời có nội dung đầy đủ." if len(text) < 80 else ""), "finish_reason":"stop", "usage":{"total_tokens":10}, "model":"mock-model", "response_id":"r1"}

PLAN = json.dumps({
 "task_summary":"Kiểm thử hệ thống",
 "deliverables":["Báo cáo kiểm thử"],
 "specialists":["analyst"],
 "acceptance_criteria":["Kiểm thử thành công"],
 "risks":[]
}, ensure_ascii=False)

class Tests(unittest.TestCase):
    def test_modelclient_metadata_success(self):
        payload={"id":"abc","model":"mock","choices":[{"message":{"content":"Xin chào"},"finish_reason":"stop"}],"usage":{"total_tokens":4}}
        with patch("core.model_client.urllib.request.urlopen", return_value=FakeResponse(payload)):
            r=ModelClient().chat_with_metadata([{"role":"user","content":"x"}])
        self.assertEqual(r["content"],"Xin chào"); self.assertEqual(r["finish_reason"],"stop")
        self.assertEqual(r["usage"]["total_tokens"],4); self.assertEqual(r["response_id"],"abc")
    def test_modelclient_legacy_string(self):
        payload={"choices":[{"message":{"content":"legacy"},"finish_reason":"stop"}]}
        with patch("core.model_client.urllib.request.urlopen", return_value=FakeResponse(payload)):
            self.assertEqual(ModelClient().chat([{"role":"user","content":"x"}]),"legacy")
    def test_modelclient_multiblock_content(self):
        payload={"choices":[{"message":{"content":[{"text":"part one"},{"text":"part two"}]},"finish_reason":"stop"}]}
        with patch("core.model_client.urllib.request.urlopen", return_value=FakeResponse(payload)):
            got=ModelClient().chat_with_metadata([])["content"]
        self.assertEqual(got, "part one\npart two")
    def test_modelclient_bad_shape_raises(self):
        with patch("core.model_client.urllib.request.urlopen", return_value=FakeResponse({"choices":[]})):
            with self.assertRaises(ModelError): ModelClient().chat_with_metadata([])
    def test_modelclient_http_error(self):
        import urllib.error
        e=urllib.error.HTTPError("u",429,"rate",{},None)
        e.read=lambda: b'{"error":"rate"}'
        with patch("core.model_client.urllib.request.urlopen", side_effect=e):
            with self.assertRaisesRegex(ModelError,"HTTP 429"): ModelClient().chat_with_metadata([])
    def test_specialist_metadata_and_prompt(self):
        m=FakeModel([good()])
        a=SpecialistAgent("A","role","instructions",m,777)
        r=a.run_with_metadata("task","ctx","plan_only")
        self.assertEqual(r["content"],good()["content"])
        self.assertEqual(m.calls[0][2],777)
        self.assertIn("PLAN ONLY",m.calls[0][0][0]["content"])
        self.assertIn("ctx",m.calls[0][0][1]["content"])
    def test_specialist_accepts_higher_retry_token_budget(self):
        m=FakeModel([good()])
        a=SpecialistAgent("A","role","instructions",m,1000)
        a.run_with_metadata("task", max_tokens=2600)
        self.assertEqual(m.calls[0][2],2600)

    def test_specialist_legacy_returns_string(self):
        m=FakeModel([good()])
        a=SpecialistAgent("A","role","instructions",m)
        self.assertIsInstance(a.run("task"),str)
    def test_specialist_legacy_model_fallback(self):
        class Legacy:
            model="old"
            def chat(self, messages, max_tokens=None): return "legacy content"
        a=SpecialistAgent("A","role","instructions",Legacy())
        r=a.run_with_metadata("task")
        self.assertEqual(r["content"],"legacy content")
        self.assertIsNone(r["finish_reason"])
        self.assertFalse(r["metadata_available"])
    def test_plan_parser_forces_analyst_and_deduplicates(self):
        o=Orchestrator.__new__(Orchestrator)
        o.registry=type("R",(),{"agents":{"analyst":1,"qa":1,"devops":1}})()
        p=o._parse_plan('```json\\n{"specialists":["qa","qa","fake"]}\\n```',"implementation")
        self.assertEqual(p["specialists"],["analyst","qa"])
    def test_analysis_mode_only_analyst(self):
        o=Orchestrator.__new__(Orchestrator)
        o.registry=type("R",(),{"agents":{"analyst":1,"qa":1}})()
        p=o._parse_plan('{"specialists":["qa"]}',"analysis_only")
        self.assertEqual(p["specialists"],["analyst"])
    def test_quality_detects_empty_and_repetition(self):
        o=Orchestrator.__new__(Orchestrator)
        self.assertEqual(o._validate_result("", "implementation")["quality_status"],"rejected")
        repeated=("mot mot mot " * 40)
        self.assertEqual(o._validate_result(repeated,"implementation")["quality_status"],"rejected")

    def test_quality_allows_repeated_domain_terms_across_report(self):
        o=Orchestrator.__new__(Orchestrator)
        report = (
            "Yêu cầu chức năng: đồng bộ hóa dữ liệu khi có mạng. "
            "Yêu cầu ngoại tuyến: đồng bộ hóa sau khi kết nối trở lại. "
            "Rủi ro dữ liệu: đồng bộ hóa có thể phát sinh xung đột. "
            "Kiến trúc đề xuất: đồng bộ hóa theo hàng đợi cục bộ. "
            "Kiểm thử: đồng bộ hóa phải hoàn tất trong thời gian quy định. "
            "Khả năng phục hồi: đồng bộ hóa được thử lại khi lỗi mạng. "
            "Bảo mật: đồng bộ hóa phải dùng kênh truyền được mã hóa. "
            "Vận hành: đồng bộ hóa cần ghi nhận trạng thái xử lý. "
            "Tiêu chí nghiệm thu: đồng bộ hóa không được làm mất dữ liệu."
        )
        q=o._validate_result(report,"analysis_only")
        self.assertEqual(q["quality_status"],"accepted",q["violations"])
    def test_quality_detects_code_in_plan_mode(self):
        o=Orchestrator.__new__(Orchestrator)
        q=o._validate_result("```python\\nprint(1)\\n```","plan_only")
        self.assertEqual(q["quality_status"],"rejected")
    def test_length_metadata_requests_repair(self):
        o=Orchestrator.__new__(Orchestrator)
        self.assertTrue(o._metadata_needs_repair({"finish_reason":"length"}))
        self.assertFalse(o._metadata_needs_repair({"finish_reason":"stop"}))
    def test_context_caps(self):
        o=Orchestrator.__new__(Orchestrator)
        out=o._build_context(["a"*3000,"b"*3000,"c"*3000,"d"*3000])
        self.assertLessEqual(len(out),o.MAX_CONTEXT_TOTAL)
        self.assertLessEqual(out.count("RESULT"),3)
    def test_pipeline_success_report(self):
        o=Orchestrator.__new__(Orchestrator)
        o.model=FakeModel([{"content":PLAN,"finish_reason":"stop","usage":{"total_tokens":5},"model":"mock","response_id":"p1"}])
        a=FakeAgent("Analyst",[good()])
        o.registry=type("R",(),{"agents":{"analyst":a},"get":lambda self,k:a})()
        o.detect_task_mode=lambda task:"implementation"
        with tempfile.TemporaryDirectory() as d:
            # redirect report destination through patching module Path
            import core.orchestrator as mod
            real_path=mod.Path
            class Pathed(real_path):
                def __new__(cls, *args, **kwargs):
                    return real_path(d) if args == ("/__REPORT_ROOT__",) else real_path(*args, **kwargs)
            # Simpler patch class constant is not available; patch Path.resolve on __file__ is awkward.
            # Run pipeline and verify actual report created in workspace artifacts.
            report=o.run_pipeline("test task")
            self.assertEqual(report["summary"]["accepted"],1)
            self.assertEqual(report["planning_metadata"]["response_id"],"p1")
            self.assertEqual(report["results"][0]["metadata"]["response_id"],"r1")
    def test_pipeline_repairs_specialist_once(self):
        o=Orchestrator.__new__(Orchestrator)
        o.model=FakeModel([{"content":PLAN,"finish_reason":"stop"}])
        bad={"content":"broken","finish_reason":"length","usage":None,"model":"mock","response_id":"bad"}
        a=FakeAgent("Analyst",[bad,good("Đã sửa hoàn chỉnh, đáp ứng yêu cầu kiểm thử và có đủ thông tin cần thiết.")])
        o.registry=type("R",(),{"agents":{"analyst":a},"get":lambda self,k:a})()
        o.detect_task_mode=lambda task:"implementation"
        report=o.run_pipeline("repair task")
        self.assertEqual(len(a.calls),2)
        self.assertTrue(report["results"][0]["repair_attempted"])
        self.assertEqual(report["results"][0]["quality_status"],"accepted")
        self.assertEqual(a.calls[1][4], 3000)
    def test_pipeline_legacy_agent_fallback(self):
        o=Orchestrator.__new__(Orchestrator)
        o.model=FakeModel([{"content":PLAN,"finish_reason":"stop"}])
        class OldAgent:
            name="Old"
            def run(self,task,context="",mode="implementation"): return "Legacy agent response that is long enough to pass the basic quality check."
        a=OldAgent()
        o.registry=type("R",(),{"agents":{"analyst":a},"get":lambda self,k:a})()
        o.detect_task_mode=lambda task:"implementation"
        report=o.run_pipeline("legacy")
        self.assertEqual(report["summary"]["received"],1)


    def test_planning_invalid_json_repaired_once(self):
        o=Orchestrator.__new__(Orchestrator)
        invalid={"content":"not json","finish_reason":"stop"}
        repaired={"content":PLAN,"finish_reason":"stop","usage":{"total_tokens":8},"model":"mock","response_id":"p2"}
        o.model=FakeModel([invalid,repaired])
        a=FakeAgent("Analyst",[good()])
        o.registry=type("R",(),{"agents":{"analyst":a},"get":lambda self,k:a})()
        o.detect_task_mode=lambda task:"implementation"
        report=o.run_pipeline("plan repair")
        self.assertEqual(len(o.model.calls),2)
        self.assertEqual(report["planning_metadata"]["response_id"],"p2")

    def test_planning_length_repaired_once(self):
        o=Orchestrator.__new__(Orchestrator)
        truncated={"content":PLAN,"finish_reason":"length"}
        repaired={"content":PLAN,"finish_reason":"stop","response_id":"fixed"}
        o.model=FakeModel([truncated,repaired])
        a=FakeAgent("Analyst",[good()])
        o.registry=type("R",(),{"agents":{"analyst":a},"get":lambda self,k:a})()
        o.detect_task_mode=lambda task:"implementation"
        report=o.run_pipeline("planning length")
        self.assertEqual(len(o.model.calls),2)
        self.assertEqual(report["planning_metadata"]["response_id"],"fixed")

    def test_specialist_repair_still_rejected_is_recorded(self):
        o=Orchestrator.__new__(Orchestrator)
        o.model=FakeModel([{"content":PLAN,"finish_reason":"stop"}])
        bad={"content":"","finish_reason":"length"}
        a=FakeAgent("Analyst",[bad,{"content":"","finish_reason":"length"}])
        o.registry=type("R",(),{"agents":{"analyst":a},"get":lambda self,k:a})()
        o.detect_task_mode=lambda task:"implementation"
        report=o.run_pipeline("repair fails")
        self.assertEqual(len(a.calls),2)
        self.assertEqual(report["results"][0]["quality_status"],"rejected")
        self.assertTrue(report["results"][0]["repair_attempted"])

    def test_specialist_exception_recorded(self):
        o=Orchestrator.__new__(Orchestrator)
        o.model=FakeModel([{"content":PLAN,"finish_reason":"stop"}])
        a=FakeAgent("Analyst",[RuntimeError("mock failure")])
        o.registry=type("R",(),{"agents":{"analyst":a},"get":lambda self,k:a})()
        o.detect_task_mode=lambda task:"implementation"
        report=o.run_pipeline("specialist error")
        self.assertEqual(report["summary"]["failed"],1)
        self.assertIn("mock failure",report["results"][0]["error"])

    def test_orchestrator_legacy_model_fallback(self):
        o=Orchestrator.__new__(Orchestrator)
        class OldModel:
            model="old-model"
            def chat(self,messages,max_tokens=None): return PLAN
        o.model=OldModel()
        response=o.run_task_with_metadata("task","implementation")
        self.assertEqual(response["content"],PLAN)
        self.assertFalse(response["metadata_available"])
        self.assertEqual(o.run_task("task","implementation"),PLAN)

    def test_task_mode_detection(self):
        o=Orchestrator.__new__(Orchestrator)
        self.assertEqual(o.detect_task_mode("Chỉ phân tích yêu cầu"),"analysis_only")
        self.assertEqual(o.detect_task_mode("Chưa viết code, hãy lập kế hoạch"),"plan_only")
        self.assertEqual(o.detect_task_mode("Xây dựng ứng dụng"),"implementation")

    def test_report_json_serializable(self):
        o=Orchestrator.__new__(Orchestrator)
        o.model=FakeModel([{"content":PLAN,"finish_reason":"stop","usage":{"prompt_tokens":1,"completion_tokens":2}}])
        a=FakeAgent("Analyst",[good()])
        o.registry=type("R",(),{"agents":{"analyst":a},"get":lambda self,k:a})()
        o.detect_task_mode=lambda task:"implementation"
        report=o.run_pipeline("serialization")
        encoded=json.dumps(report,ensure_ascii=False)
        self.assertIn('"planning_metadata"',encoded)
        self.assertIn('"usage"',encoded)


    def test_modelclient_timeout_maps_error(self):
        with patch("core.model_client.urllib.request.urlopen", side_effect=TimeoutError("late")):
            with self.assertRaisesRegex(ModelError,"timeout"): ModelClient().chat_with_metadata([])

    def test_modelclient_url_error_maps_error(self):
        import urllib.error
        with patch("core.model_client.urllib.request.urlopen", side_effect=urllib.error.URLError("offline")):
            with self.assertRaisesRegex(ModelError,"Không kết nối"): ModelClient().chat_with_metadata([])

    def test_modelclient_empty_content_rejected(self):
        payload={"choices":[{"message":{"content":"  "},"finish_reason":"stop"}]}
        with patch("core.model_client.urllib.request.urlopen", return_value=FakeResponse(payload)):
            with self.assertRaisesRegex(ModelError,"không đúng định dạng"): ModelClient().chat_with_metadata([])

    def test_repair_feedback_uses_real_newlines(self):
        o=Orchestrator.__new__(Orchestrator)
        feedback=o._repair_feedback({"finish_reason":"length"},{"violations":["Lỗi A","Lỗi B"],"warnings":[]})
        self.assertIn("\n- Lỗi A",feedback)
        self.assertNotIn("\\n",feedback)

    def test_planning_repair_prompt_uses_real_newline(self):
        o=Orchestrator.__new__(Orchestrator)
        o.registry=type("R",(),{"agents":{"analyst":1}})()
        o.model=FakeModel([{"content":"bad","finish_reason":"stop"},{"content":PLAN,"finish_reason":"stop"}])
        o.run_task_with_metadata("task", "implementation", repair_feedback="bad json")
        self.assertIn("\n",o.model.calls[-1][0][-1]["content"])
        self.assertNotIn("\\n",o.model.calls[-1][0][-1]["content"])

if __name__=="__main__":
    unittest.main(verbosity=2)
