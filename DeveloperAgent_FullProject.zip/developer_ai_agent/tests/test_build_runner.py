import json
import tempfile
import unittest
import zipfile
from pathlib import Path

from core.build_runner import BuildRunner


class FakeModel:
    model = "fake-model"

    def chat_with_metadata(self, messages, **kwargs):
        payload = {
            "summary": "Tạo tệp ứng dụng mẫu để kiểm tra luồng build.",
            "files": [{"path": "app.py", "content": "def main():\n    return 'ready'\n\nif __name__ == '__main__':\n    print(main())\n"}],
        }
        return {"content": json.dumps(payload), "finish_reason": "stop", "usage": {}, "model": self.model, "response_id": "test"}


class BuildRunnerTests(unittest.TestCase):
    def test_build_writes_checks_and_packages(self):
        with tempfile.TemporaryDirectory() as temp:
            workspace = Path(temp) / "project"
            workspace.mkdir()
            output = Path(temp) / "Download" / "project.zip"
            pipeline = {
                "plan": {"task_summary": "Tạo app mẫu"},
                "results": [{"quality_status": "accepted", "agent_name": "Analyst", "result": "Yêu cầu mẫu đã được phân tích đầy đủ."}],
            }
            report = BuildRunner(workspace, model_client=FakeModel()).execute("Tạo app mẫu", pipeline, output)
            self.assertEqual(report["status"], "completed")
            self.assertTrue(report["checks_passed"])
            self.assertTrue(report["checks_available"])
            self.assertTrue(output.is_file())
            self.assertTrue((workspace / "app.py").is_file())
            with zipfile.ZipFile(output) as archive:
                self.assertIsNone(archive.testzip())
                self.assertTrue(any(name.endswith("app.py") for name in archive.namelist()))


    def test_truncated_batch_falls_back_to_manifest_and_one_file_calls(self):
        class IncrementalModel:
            model = "fake-model"
            def __init__(self):
                self.calls = 0
            def chat_with_metadata(self, messages, **kwargs):
                self.calls += 1
                if self.calls == 1:
                    return {"content": "", "finish_reason": "length"}
                if self.calls == 2:
                    return {"content": json.dumps({
                        "summary": "Tạo ứng dụng theo từng tệp.",
                        "files": [
                            {"path": "note_manager.py", "purpose": "CLI CRUD và JSON"},
                            {"path": "test_note_manager.py", "purpose": "Kiểm thử CRUD"}
                        ]
                    }), "finish_reason": "stop"}
                if self.calls == 3:
                    return {"content": json.dumps({
                        "path": "note_manager.py",
                        "content": "def main():\\n    return 0\\n"
                    }), "finish_reason": "stop"}
                return {"content": json.dumps({
                    "path": "test_note_manager.py",
                    "content": "def test_main():\\n    assert True\\n"
                }), "finish_reason": "stop"}

        with tempfile.TemporaryDirectory() as temp:
            workspace = Path(temp) / "project"
            workspace.mkdir()
            runner = BuildRunner(workspace, model_client=IncrementalModel())
            result = runner._ask_for_changes("Tạo app", {}, [], "(empty)")
            self.assertEqual([x["path"] for x in result["files"]],
                             ["note_manager.py", "test_note_manager.py"])
            self.assertEqual(len(result["files"]), 2)
            self.assertEqual(runner.model.calls, 4)
            self.assertFalse((runner.engine.workspace / "note_manager.py").exists())

    def test_incremental_file_response_ignores_trailing_model_chatter(self):
        class TrailingModel:
            model = "fake-model"
            def __init__(self): self.calls = 0
            def chat_with_metadata(self, messages, **kwargs):
                self.calls += 1
                if self.calls == 1:
                    return {"content": "", "finish_reason": "length"}
                if self.calls == 2:
                    return {"content": json.dumps({"summary": "Tạo app.", "files": [{"path": "notes/core.py", "purpose": "CRUD"}]}), "finish_reason": "stop"}
                payload = {"path": "notes/core.py", "content": "def add_note():\n    return True\n"}
                return {"content": json.dumps(payload) + "\n\nHoàn tất tệp.", "finish_reason": "stop"}
        with tempfile.TemporaryDirectory() as temp:
            workspace = Path(temp) / "project"
            workspace.mkdir()
            runner = BuildRunner(workspace, model_client=TrailingModel())
            result = runner._ask_for_changes("Tạo app", {}, [], "(empty)")
            self.assertEqual(result["files"][0]["path"], "notes/core.py")
            self.assertIn("def add_note", result["files"][0]["content"])

    def test_extract_json_tolerates_trailing_fence_and_explanation(self):
        raw = '```json\n{"summary":"ok","files":[]}\n```\nDone.'
        self.assertEqual(BuildRunner._extract_json(raw), {"summary": "ok", "files": []})

    def test_invalid_batch_is_rejected_before_any_file_write(self):
        with tempfile.TemporaryDirectory() as temp:
            workspace = Path(temp) / "project"
            workspace.mkdir()
            runner = BuildRunner(workspace, model_client=FakeModel())
            with self.assertRaises(RuntimeError):
                runner._apply_files([
                    {"path": "first.py", "content": "print('safe')"},
                    {"path": "../escape.py", "content": "print('unsafe')"},
                ])
            self.assertFalse((workspace / "first.py").exists())

    def test_no_accepted_specialist_stops_before_changes(self):
        with tempfile.TemporaryDirectory() as temp:
            workspace = Path(temp) / "project"
            workspace.mkdir()
            pipeline = {"plan": {}, "results": [{"quality_status": "rejected"}]}
            with self.assertRaises(RuntimeError):
                BuildRunner(workspace, model_client=FakeModel()).execute("x", pipeline, Path(temp) / "out.zip")
            self.assertEqual({p.name for p in workspace.iterdir()}, {".agent_logs", ".agent_backups"})


if __name__ == "__main__":
    unittest.main()
