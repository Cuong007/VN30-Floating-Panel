import tempfile
import unittest
import zipfile
from pathlib import Path

from core.execution_engine import ExecutionEngine, ExecutionError


class ExecutionEngineTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name) / "workspace"
        self.root.mkdir()
        self.engine = ExecutionEngine(self.root)

    def tearDown(self):
        self.temp.cleanup()

    def test_write_read_and_backup(self):
        self.engine.write_file("app.py", "print('one')\n")
        result = self.engine.write_file("app.py", "print('two')\n")
        self.assertTrue(result["backup"])
        self.assertEqual(self.engine.read_file("app.py"), "print('two')\n")
        self.assertTrue(Path(result["backup"]).is_file())

    def test_reject_path_traversal(self):
        with self.assertRaises(ExecutionError):
            self.engine.write_file("../escape.txt", "bad")

    def test_reject_secret_file(self):
        with self.assertRaises(ExecutionError):
            self.engine.write_file(".env", "SECRET=x")

    def test_reject_internal_directories(self):
        with self.assertRaises(ExecutionError):
            self.engine.write_file(".git/config", "unsafe")

    def test_package_does_not_follow_external_symlink(self):
        outside = Path(self.temp.name) / "outside.txt"
        outside.write_text("private", encoding="utf-8")
        (self.root / "linked.txt").symlink_to(outside)
        out = Path(self.temp.name) / "safe.zip"
        self.engine.package_zip(out)
        with zipfile.ZipFile(out) as archive:
            self.assertFalse(any(name.endswith("linked.txt") for name in archive.namelist()))

    def test_reject_unsafe_command(self):
        with self.assertRaises(ExecutionError):
            self.engine.run_command(["python", "-c", "print('unsafe')"])
        with self.assertRaises(ExecutionError):
            self.engine.run_command("python -m unittest; rm -rf /")

    def test_compile_and_unittest_commands(self):
        self.engine.write_file("sample.py", "VALUE = 1\n")
        result = self.engine.run_command(["python", "-m", "compileall", "-q", "."])
        self.assertTrue(result["passed"], result)

    def test_package_excludes_env_and_internal_logs(self):
        self.engine.write_file("main.py", "print('ok')\n")
        (self.root / ".env").write_text("SECRET=never", encoding="utf-8")
        out = Path(self.temp.name) / "deliverable.zip"
        result = self.engine.package_zip(out)
        self.assertTrue(out.is_file())
        self.assertEqual(result["files"], 1)
        with zipfile.ZipFile(out) as archive:
            names = archive.namelist()
            self.assertTrue(any(name.endswith("main.py") for name in names))
            self.assertFalse(any(name.endswith(".env") for name in names))
            self.assertIsNone(archive.testzip())


if __name__ == "__main__":
    unittest.main()
