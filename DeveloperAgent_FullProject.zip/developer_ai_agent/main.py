import argparse
import sys

from config.settings import KILO_MODEL, KILO_BASE_URL
from core.model_client import ModelError
from core.orchestrator import Orchestrator


def main():
    parser = argparse.ArgumentParser(
        description="General-Purpose Multi-Agent Developer AI Agent"
    )

    parser.add_argument("--check", action="store_true")
    parser.add_argument("--test-model", action="store_true")
    parser.add_argument("--task", type=str)
    parser.add_argument("--build", type=str, help="Yêu cầu phát triển và thực thi trong workspace")
    parser.add_argument("--workspace", type=str, help="Thư mục dự án được phép thao tác")
    parser.add_argument("--output", type=str, help="Đường dẫn ZIP bàn giao; mặc định lưu vào Download")

    args = parser.parse_args()

    if args.check:
        from agents.registry import SpecialistRegistry

        registry = SpecialistRegistry()

        print("===== DEVELOPER AI AGENT CHECK =====")
        print("Model:", KILO_MODEL)
        print("Endpoint:", KILO_BASE_URL)
        print("Specialists:", len(registry.agents))
        print("Orchestrator: READY")
        print("CHECK: PASS")
        return

    if args.test_model:
        try:
            orchestrator = Orchestrator()
            result = orchestrator.model.chat([
                {
                    "role": "user",
                    "content": "Trả lời ngắn: AI đang hoạt động."
                }
            ])
            print(result)
            print("MODEL TEST: PASS")

        except ModelError as exc:
            print("MODEL TEST: FAIL")
            print(exc)
            sys.exit(1)

        return

    if args.build:
        if not args.workspace:
            parser.error("--build yêu cầu --workspace")
        try:
            from pathlib import Path
            from core.build_runner import BuildRunner
            orchestrator = Orchestrator()
            pipeline_report = orchestrator.run_pipeline(args.build)
            if pipeline_report.get("summary", {}).get("failed", 0) or pipeline_report.get("summary", {}).get("rejected", 0):
                raise RuntimeError("Pipeline có Specialist lỗi hoặc bị từ chối; dừng trước khi sửa workspace.")
            output = args.output or str(Path.home() / "storage" / "downloads" / (Path(args.workspace).name + "_deliverable.zip"))
            report = BuildRunner(args.workspace, model_client=orchestrator.model).execute(args.build, pipeline_report, output)
            print("\n===== BUILD SUMMARY =====")
            print("STATUS:", report["status"])
            print("FILES CHANGED:", len(report["changes"]))
            print("CHECKS:", "PASS" if report["checks_passed"] else ("NOT AVAILABLE" if not report["checks_available"] else "FAIL"))
            print("PACKAGE:", report["package"]["path"] if report["package"] else "NOT CREATED")
            print("REPORT:", report["report_path"])
            if report["status"] == "needs_repair":
                sys.exit(2)
        except Exception as exc:
            print("BUILD ERROR:")
            print(f"{type(exc).__name__}: {exc}")
            sys.exit(1)
        return

    if args.task:
        try:
            orchestrator = Orchestrator()
            orchestrator.run_pipeline(args.task)

        except Exception as exc:
            print("PIPELINE ERROR:")
            print(f"{type(exc).__name__}: {exc}")
            sys.exit(1)

        return

    parser.print_help()


if __name__ == "__main__":
    main()
