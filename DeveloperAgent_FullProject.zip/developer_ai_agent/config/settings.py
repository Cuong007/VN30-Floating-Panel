import os
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent.parent
ENV_FILE = ROOT_DIR / ".env"


def load_env():
    if not ENV_FILE.exists():
        return

    for line in ENV_FILE.read_text(encoding="utf-8").splitlines():
        line = line.strip()

        if not line or line.startswith("#") or "=" not in line:
            continue

        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")

        if key and key not in os.environ:
            os.environ[key] = value


load_env()

KILO_BASE_URL = os.getenv(
    "KILO_BASE_URL",
    "https://ai-gateway.kilo.ai/api/v1/chat/completions"
)

KILO_MODEL = os.getenv(
    "KILO_MODEL",
    "cohere/north-mini-code:free"
)

KILO_API_KEY = os.getenv("KILO_API_KEY", "")

REQUEST_TIMEOUT = int(os.getenv("REQUEST_TIMEOUT", "90"))
MAX_TOKENS = int(os.getenv("MAX_TOKENS", "4096"))
TEMPERATURE = float(os.getenv("TEMPERATURE", "0.2"))
