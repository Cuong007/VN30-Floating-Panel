# Execution Engine – hướng dẫn sử dụng

## Chế độ phân tích cũ

```bash
python main.py --task "Chỉ phân tích yêu cầu ..."
```

## Chế độ phát triển và đóng gói

Chỉ định rõ thư mục dự án mà Agent được phép thao tác:

```bash
python main.py --build "Tạo ứng dụng quản lý ghi chú đơn giản bằng Python, có thêm/sửa/xóa và lưu dữ liệu JSON. Viết kiểm thử tự động." --workspace "$HOME/storage/shared/my_notes_app"
```

Nếu không chỉ định `--output`, ZIP bàn giao được lưu tại:

```text
~/storage/downloads/<ten_workspace>_deliverable.zip
```

Có thể chỉ định nơi lưu ZIP:

```bash
python main.py --build "..." --workspace "$HOME/storage/shared/my_project" --output "$HOME/storage/downloads/my_project.zip"
```

## Luồng thực hiện

1. Orchestrator lập kế hoạch và gọi các Specialist liên quan.
2. Chỉ tiếp tục nếu có kết quả Specialist được chấp nhận và không có Specialist lỗi/bị từ chối.
3. Implementation Engine đọc một tập hợp giới hạn các tệp văn bản trong workspace và yêu cầu model đề xuất thay đổi theo JSON.
4. Kiểm tra toàn bộ đường dẫn và kích thước trước khi ghi; sao lưu tệp cũ trước khi thay thế.
5. Chạy compileall và unittest nếu workspace có mã Python; tối đa hai vòng sửa dựa trên lỗi kiểm thử.
6. Chỉ tạo ZIP khi các kiểm tra tự động đã chạy đều đạt.

## Ranh giới và giới hạn an toàn

- API đọc/ghi/xóa chỉ chấp nhận đường dẫn nằm trong workspace; từ chối đường dẫn traversal, symlink thoát workspace và thư mục nội bộ.
- Không cho phép Agent ghi `.env` hoặc các tệp bí mật; ZIP không chứa `.env`, cache, backup, log nội bộ hay thư mục artifacts.
- Tệp cũ được sao lưu vào `.agent_backups`; nhật ký thao tác nằm trong `.agent_logs`.
- Chỉ cho chạy một danh sách lệnh kiểm tra cố định; lệnh chạy không qua shell.
- **Đây không phải sandbox cấp hệ điều hành.** Các bài test được chạy với quyền Termux của người dùng và mã test có thể thực thi mã dự án. Chỉ dùng `--build` với workspace và mã nguồn mà bạn tin cậy.
- Model có thể trả về thay đổi chưa hoàn chỉnh hoặc chưa phù hợp yêu cầu. Kết quả `completed` chỉ có nghĩa là các kiểm tra tự động đã cấu hình chạy đạt; không thay thế review chức năng/thủ công.
- Nếu dự án không có test Python, engine chỉ có thể chạy những kiểm tra tự động nhận diện được; ZIP sẽ được tạo với giới hạn này được ghi trong báo cáo.
