from core.model_client import ModelClient


class SpecialistAgent:
    def __init__(self, name, role, instructions, model_client=None,
                 max_tokens=1200):
        self.name = name
        self.role = role
        self.instructions = instructions
        self.model = model_client or ModelClient()
        self.max_tokens = max_tokens

    def _build_messages(self, task, context="", mode="implementation",
                        repair_feedback=None):
        mode_instructions = {
            "analysis_only": """
TASK MODE: ANALYSIS ONLY
- Analyze and explain only.
- Do not write source code, executable scripts, configurations, or code blocks.
- Focus on requirements, findings and recommendations.
""",
            "plan_only": """
TASK MODE: PLAN ONLY
- Produce plans, specifications and technical designs only.
- Do not write source code, implementation code, executable scripts,
  complete configuration files, or implementation code blocks.
- You may describe architecture, algorithms, interfaces, data structures,
  test cases and implementation steps in prose.
""",
            "implementation": """
TASK MODE: IMPLEMENTATION
You may produce implementation code when assigned to do so.
Preserve existing functionality.
""",
        }
        mode_instruction = mode_instructions.get(
            mode, mode_instructions["implementation"]
        )
        system_prompt = f"""
You are a specialist AI agent in a General-Purpose Multi-Agent
Software Development System.
SPECIALIST: {self.name}
ROLE: {self.role}
YOUR INSTRUCTIONS:
{self.instructions}
{mode_instruction}
GENERAL RULES:
- Focus only on your assigned responsibility.
- Be precise and technically practical.
- Identify assumptions and missing information.
- Never claim code was executed or files changed unless true.
- Do not invent test results or research findings.
- Avoid repetition.
- Use clear headings and concise explanations.
- Communicate in Vietnamese.
- Finish your response completely.
"""
        specialist_output_rules = {
            "Architect Agent": """
- Chỉ đưa ra thiết kế kiến trúc và quyết định kỹ thuật; KHÔNG viết mã nguồn.
- Tối đa 6 mục, mỗi mục tối đa 5 gạch đầu dòng; tối đa khoảng 450 từ.
- Không tạo code fence, không chép lại yêu cầu hoặc nội dung Analyst.
""",
            "Backend Agent": """
- Chỉ đưa ra đặc tả triển khai backend: mô-đun/tệp, API/hàm, dữ liệu,
  validation, lỗi và lưu trữ. KHÔNG viết toàn bộ mã nguồn.
- Tối đa khoảng 450 từ; không code fence; tránh lặp kiến trúc.
""",
            "QA Agent": """
- Chỉ đưa ma trận kiểm thử: trường hợp, đầu vào, kết quả mong đợi và rủi ro.
- KHÔNG viết mã nguồn hoặc tạo bộ test hoàn chỉnh.
- Tối đa khoảng 350 từ; không code fence; không lặp lại đặc tả.
""",
            "Analyst Agent": """
- Tập trung yêu cầu đã xác nhận, giả định và tiêu chí nghiệm thu.
- Tối đa khoảng 450 từ; không code nguồn.
""",
        }.get(self.name, "- Trả lời súc tích, tối đa khoảng 450 từ; không tạo mã nguồn đầy đủ.\n")
        user_prompt = f"""
TASK:
{task}
CONTEXT FROM OTHER AGENTS:
{context if context else "Chưa có kết quả từ Agent trước."}
OUTPUT REQUIREMENTS:
- Complete only your assigned responsibility.
- Do not repeat the entire task or other agents' work unnecessarily.
- Prioritize useful, concrete information.
- Respect the configured output limit.
- Do not claim actions you did not perform.
{specialist_output_rules}
- Implementation Engineer (BuildRunner) sẽ viết mã nguồn sau khi tổng hợp kết quả.
"""
        if repair_feedback:
            user_prompt += f"""
REPAIR REQUIRED:
Your previous response failed quality validation.
Regenerate the COMPLETE response; do not merely append missing text.
Fix these issues:
{repair_feedback}
"""
        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

    def run_with_metadata(self, task, context="", mode="implementation",
                          repair_feedback=None, max_tokens=None):
        messages = self._build_messages(
            task, context, mode, repair_feedback
        )
        method = getattr(self.model, "chat_with_metadata", None)
        token_budget = self.max_tokens if max_tokens is None else max_tokens
        last_response = None

        # Empty assistant content can occur intermittently on shared free
        # inference capacity. Retry locally with a shorter, explicit prompt
        # before allowing the Orchestrator's quality-repair stage to run.
        for attempt in range(3):
            if callable(method):
                response = method(messages, max_tokens=token_budget)
                if not isinstance(response, dict) or not isinstance(
                    response.get("content"), str
                ):
                    raise TypeError("ModelClient trả về metadata không hợp lệ.")
            else:
                content = self.model.chat(messages, max_tokens=token_budget)
                response = {
                    "content": content,
                    "finish_reason": None,
                    "usage": None,
                    "model": getattr(self.model, "model", None),
                    "response_id": None,
                    "metadata_available": False,
                }
                if not isinstance(content, str):
                    raise TypeError("ModelClient trả về nội dung không phải chuỗi.")

            last_response = response
            if response["content"].strip():
                return response

            if attempt < 2:
                reason = response.get("finish_reason")
                repair_feedback = (
                    "Phản hồi trước hoàn toàn rỗng"
                    + (f" (finish_reason={reason})" if reason else "")
                    + ". Hãy trả lời trực tiếp bằng văn bản thuần, bắt đầu ngay "
                      "bằng tiêu đề và tối đa 8 gạch đầu dòng. Không dùng code fence, "
                      "không giải thích quá trình suy luận, không để trống nội dung."
                )
                messages = self._build_messages(
                    task, context, mode, repair_feedback=repair_feedback
                )
                token_budget = min(max(token_budget * 2, 1600), 3000)

        return last_response

    def run(self, task, context="", mode="implementation"):
        # API cũ vẫn trả về chuỗi, không làm hỏng caller hiện tại.
        return self.run_with_metadata(task, context, mode)["content"]
