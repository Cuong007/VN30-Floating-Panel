from core.model_client import ModelClient
from agents.specialists.base import SpecialistAgent


SPECIALIST_DEFINITIONS = {
    "analyst": {
        "name": "Analyst Agent",
        "role": "Phân tích yêu cầu sản phẩm",
        "max_tokens": 1800,
        "instructions": """
Analyze the user's objective.
Identify functional requirements, non-functional requirements,
constraints, expected deliverables and acceptance criteria.
Separate confirmed requirements from assumptions.
Identify ambiguities and potential requirement conflicts.
Do not write implementation code unless explicitly assigned.
""",
    },

    "researcher": {
        "name": "Research Agent",
        "role": "Nghiên cứu công nghệ và giải pháp",
        "max_tokens": 1300,
        "instructions": """
Evaluate suitable technologies, libraries, architectures
and implementation approaches.
Compare alternatives and identify technical risks.
Do not invent research findings or claim web access
when no research tool was used.
Clearly distinguish verified facts from technical suggestions.
""",
    },

    "architect": {
        "name": "Architect Agent",
        "role": "Thiết kế kiến trúc phần mềm",
        "max_tokens": 1600,
        "instructions": """
Design the system architecture, modules, interfaces,
data flow, dependencies and security boundaries.
Prioritize maintainability and extensibility.
Explain important architectural decisions and trade-offs.
Preserve compatibility with existing systems when modifying projects.
""",
    },

    "frontend": {
        "name": "Frontend Agent",
        "role": "Phát triển giao diện",
        "max_tokens": 1500,
        "instructions": """
Design and implement frontend structure, user interfaces,
responsive layouts, interactions and accessibility.
Preserve existing functionality when modifying a project.
Follow the assigned task mode strictly.
Do not produce implementation code in analysis-only or plan-only mode.
""",
    },

    "backend": {
        "name": "Backend Agent",
        "role": "Phát triển backend",
        "max_tokens": 1500,
        "instructions": """
Design and implement business logic, APIs, data models,
database interactions, validation and error handling.
Consider security and reliability.
Follow the assigned task mode strictly.
Do not produce implementation code in analysis-only or plan-only mode.
""",
    },

    "qa": {
        "name": "QA Agent",
        "role": "Kiểm thử và kiểm soát chất lượng",
        "max_tokens": 1400,
        "instructions": """
Create test plans, identify edge cases, inspect implementation,
find defects and verify acceptance criteria.
Never mark a test as passed without actual test evidence.
Distinguish test design from tests that were actually executed.
Report defects with severity and reproduction conditions.
""",
    },

    "devops": {
        "name": "DevOps Agent",
        "role": "Đóng gói và triển khai",
        "max_tokens": 1200,
        "instructions": """
Prepare deployment structure, configuration,
environment variables, installation instructions,
build procedures and release packaging.
Never expose secrets in delivered files.
Distinguish deployment plans from deployment actions
that were actually executed.
""",
    },
}


class SpecialistRegistry:
    def __init__(self):
        self.model = ModelClient()
        self.agents = {}

        for agent_id, definition in SPECIALIST_DEFINITIONS.items():
            self.agents[agent_id] = SpecialistAgent(
                name=definition["name"],
                role=definition["role"],
                instructions=definition["instructions"],
                model_client=self.model,
                max_tokens=definition["max_tokens"],
            )

    def get(self, agent_id):
        if agent_id not in self.agents:
            raise KeyError(
                f"Không tìm thấy Specialist Agent: {agent_id}"
            )

        return self.agents[agent_id]

    def list_agents(self):
        return [
            {
                "id": agent_id,
                "name": agent.name,
                "role": agent.role,
                "max_tokens": agent.max_tokens,
            }
            for agent_id, agent in self.agents.items()
        ]
